"""迭代流程（第 6 节每轮 10 步），第一期实现范围：
- 生产者 2 个及以上、审查者 1 个及以上；
- 找茬者、记录者尚未实现，对应步骤只记事件；
- 准入门由用户手动放行（创建项目即视为放行，入账"准入：用户手动放行"）。
"""

from __future__ import annotations

import json

from . import blocks as B
from .models import CallFailedPause
from .tasks import fact_compilation as T
from .util import FormatError, canonical_json, find_numbers, normalize_ws, sha256_text


class Flow:
    def __init__(self, project, settings, hub, retriever):
        self.p, self.s, self.hub, self.ret = project, settings, hub, retriever
        self.cfg = project.config
        self.items = self.cfg["items"]
        self.item_ids = {it["id"] for it in self.items}
        self.roles = settings["roles"]
        self.producers = [r for r, v in self.roles.items() if v["kind"] == "生产者"]
        self.reviewers = [r for r, v in self.roles.items() if v["kind"] == "审查者"]
        if len(self.producers) < 2 or len(self.reviewers) < 1:
            raise ValueError("第一期至少需要 2 个生产者、1 个审查者")
        self._novelty = {}
        self._init_items()

    # ---------------- 基础 ----------------
    def _init_items(self):
        for it in self.items:
            if not self.p.q("SELECT 1 FROM items WHERE item_id=?", (it["id"],)):
                self.p.exec("INSERT INTO items (item_id,name,type,st_check,st_verify,st_indep,st_valid,history)"
                            " VALUES (?,?,?,?,?,?,?,?)",
                            (it["id"], it["name"], "条目", "未查证", "未验证", None, "有效", "[]"))

    def series(self, role):
        return self.roles[role].get("series", role)

    def completed_rounds(self):
        rows = self.p.q("SELECT round FROM events WHERE type='轮次完成' ORDER BY seq")
        return [r["round"] for r in rows]

    def is_finished(self):
        return bool(self.p.q("SELECT 1 FROM events WHERE type='迭代结束'"))

    def blocks_of(self, role, round_):
        rows = self.p.q("SELECT * FROM blocks WHERE author=? AND round=? AND st_valid='有效'", (role, round_))
        return [dict(r) for r in rows]

    def open_opinions(self, role):
        rows = self.p.q("SELECT * FROM opinions WHERE target_author=? AND status IN ('提出','核验中')", (role,))
        return [dict(r) for r in rows]

    def artifact_of(self, role, round_):
        r = self.p.q("SELECT * FROM artifacts WHERE author=? AND round=? AND type='方案' AND status='有效'",
                     (role, round_))
        return dict(r[0]) if r else None

    def _discard_incomplete(self, r):
        """未完成的轮次重做：清掉该轮的表记录后按同样的编号重建（账本事件保留，只追加，
        并记一条"重做未完成轮次"事件；已成功的模型调用与检索直接复用存档，不重复发出）。"""
        n = self.p.q("SELECT COUNT(*) c FROM blocks WHERE round=?", (r,))[0]["c"]
        if n:
            self.p.exec("UPDATE opinions SET status='作废' WHERE review_id IN "
                        "(SELECT review_id FROM reviews WHERE round=?)", (r,))
            self.p.exec("DELETE FROM reviews WHERE round=?", (r,))
            self.p.exec("DELETE FROM blocks WHERE round=?", (r,))
            self.p.exec("UPDATE artifacts SET status='作废' WHERE round=?", (r,))
            self.p.log("程序", "重做未完成轮次", round_=r, content={"清除块数": n})

    # ---------------- 主循环 ----------------
    def run(self):
        if not self.p.q("SELECT 1 FROM events WHERE type='准入判断'"):
            self.p.log("用户", "准入判断", content={"结果": "强制放行", "说明": "第一期未实现准入门，由用户手动放行"})
        if self.is_finished():
            return "已结束"
        done = self.completed_rounds()
        r = (max(done) + 1) if done else 1
        max_rounds = self.s["params"]["max_rounds"]
        try:
            while r <= max_rounds:
                self._discard_incomplete(r)
                finished = self.run_round(r)
                self.p.log("程序", "轮次完成", round_=r)
                if finished:
                    self.p.log("程序", "迭代结束", round_=r, content={"原因": "全部条目已有终态且无未闭合意见"})
                    return "完成"
                r += 1
            self.p.log("程序", "迭代结束", round_=r - 1, content={"原因": f"达到迭代轮次上限 {max_rounds}"})
            return "达到上限"
        except CallFailedPause as e:
            return f"调用失败暂停：{e}。检查问题后重新运行即可从失败处继续。"

    # ---------------- 一轮 ----------------
    def run_round(self, r):
        self._novelty = {}
        # 第 1 步 分发
        delivered = {}
        for p in self.producers:
            ins = [a["output_hash"] for a in (self.artifact_of(x, r - 1) for x in self.producers) if a]
            ins += [row["review_id"] for row in self.p.q("SELECT review_id FROM reviews WHERE round=?", (r - 1,))]
            delivered[p] = ins
            self.p.log("程序", "分发", round_=r, ref_type="role", ref_id=p, content={"输入": ins})
        # 第 8.9 条配置一致性检查（第 2 轮起）
        if r >= 2:
            for p in self.producers:
                authors = {a["author"] for a in self.p.q(
                    "SELECT author FROM artifacts WHERE round=? AND status='有效'", (r - 1,))} | set(self.reviewers)
                if not (authors - {p}):
                    self.p.log("程序", "配置一致性提示", round_=r, ref_id=p)

        # 第 2、3 步 生产与提交检查
        for p in self.producers:
            self.produce(p, r, delivered[p])

        # 第 4 步 对照
        table = {}
        for it in self.items:
            table[it["id"]] = {p: next((json.loads(b["fields"]).get("出生日期") for b in self.blocks_of(p, r)
                                        if b["item_id"] == it["id"]), None) for p in self.producers}
        path, h = self.p.save_artifact_file("程序", r, "对照表", json.dumps(table, ensure_ascii=False, indent=1))
        self.p.log("程序", "对照", round_=r, ref_type="file", ref_id=path, content={"hash": h})

        # 第 5、6 步 审查分发与审查（审查矩阵）
        for rv in self.reviewers:
            for p in self.producers:
                self.review(rv, p, r)
        self.apply_reviews(r)

        # 第 7—9 步
        self.p.log("程序", "找茬者未出场", round_=r, content={"说明": "第一期未实现找茬者"})
        self.p.log("程序", "回流登记", round_=r)
        self.p.log("程序", "摘要", round_=r, content={"说明": "第一期未设记录者；本轮摘要见轮次统计"})

        # 第 10 步 状态更新
        return self.update_state(r)

    # ---------------- 生产 ----------------
    def produce(self, p, r, delivered):
        own_prev = [dict(item=b["item_id"], block=b["block_id"], **json.loads(b["fields"]))
                    for b in self.blocks_of(p, r - 1)] if r > 1 else None
        others = {x: [dict(item=b["item_id"], block=b["block_id"], **json.loads(b["fields"]))
                      for b in self.blocks_of(x, r - 1)] for x in self.producers if x != p} if r > 1 else None
        ops = self.open_opinions(p)
        maxq = self.s["params"]["search_results_per_query"]

        # 检索阶段（第一期每轮检索一次；内层多次检索属第二期）
        def val_search(o):
            if not isinstance(o.get("searches"), list):
                raise FormatError("缺少 searches 数组")
            for q in o["searches"]:
                if not isinstance(q, dict):
                    raise FormatError("searches 的每一项须是 {item, query} 对象")
                if q.get("item") not in self.item_ids or not q.get("query"):
                    raise FormatError(f"检索项不合规：{q}")

        sq = self.hub.call_json(p, T.SYSTEM_PRODUCER, T.search_prompt(self.cfg, self.items, own_prev, ops),
                                call_key=f"R{r}-{p}-search", round_=r, validator=val_search)
        per_item = {}
        for q in sq["searches"][: 2 * len(self.items)]:
            prior = self.p.q("SELECT retrieval_id FROM retrievals WHERE requester=? AND round=? AND query=?",
                             (p, r, q["query"]))
            if prior:  # 恢复运行时不重复检索
                ids = [x["retrieval_id"] for x in prior]
            else:
                ids = [x["retrieval_id"] for x in self.ret.search(p, r, q["query"], maxq, item_id=q["item"])]
            per_item.setdefault(q["item"], []).extend(ids)
        evidence = {}
        for it in self.items:
            past = [x["retrieval_id"] for x in self.p.q(
                "SELECT retrieval_id FROM retrievals WHERE requester=? AND item_id=? ORDER BY retrieval_id",
                (p, it["id"]))]
            if past:
                shown = past[-self.s["params"]["max_sources_shown"]:]
                evidence[it["id"]] = T.excerpts_for(self.p, shown, it["name"])

        # 撰写阶段
        def val_product(o, bids):
            B.validate_product(o, block_schema=T.BLOCK_SCHEMA, item_ids=bids, require_changes=r > 1)
            for b in o["blocks"]:
                st = b["fields"].get("状态")
                if st not in T.ENTRY_STATES:
                    raise FormatError(f"条目 {b['item']} 的状态 {st!r} 不合规，只能是 {T.ENTRY_STATES}")
                if st != "资料缺载" and not b["fields"].get("出处"):
                    raise FormatError(f"条目 {b['item']} 状态为 {st} 时须填出处")
            got = [b["item"] for b in o["blocks"]]
            if set(got) != bids or len(got) != len(bids):
                raise FormatError(f"须为本批每个条目各提交恰好一个条目块；应为：{sorted(bids)}")

        # 分批撰写，控制单次输入长度（每批 items_per_call 个条目）
        size = self.s["params"]["items_per_call"]
        prod = {"blocks": [], "notes": "", "changes": [], "responses": []}
        for k in range(0, len(self.items), size):
            batch = self.items[k:k + size]
            bids = {it["id"] for it in batch}
            ev_b = {i: e for i, e in evidence.items() if i in bids}
            prev_b = [x for x in own_prev if x["item"] in bids] if own_prev else None
            oth_b = {x: [y for y in v if y["item"] in bids] for x, v in others.items()} if others else None
            ops_b = [o for o in ops if o["item_id"] in bids]
            part = self.hub.call_json(p, T.SYSTEM_PRODUCER,
                                      T.write_prompt(self.cfg, batch, ev_b, r, prev_b, oth_b, ops_b),
                                      call_key=f"R{r}-{p}-write-{k // size + 1}", round_=r,
                                      validator=lambda o, bids=bids: val_product(o, bids))
            for b in part["blocks"]:  # 字段值统一转为文本
                b["fields"] = {k: ("" if v is None else str(v)) for k, v in b["fields"].items()}
            prod["blocks"] += part["blocks"]
            prod["notes"] += (part.get("notes") or "")
            prod["changes"] += part.get("changes") or []
            prod["responses"] += part.get("responses") or []

        # 保存产物（程序命名）与三个哈希
        text = json.dumps(prod, ensure_ascii=False, indent=1)
        path, h = self.p.save_artifact_file(p, r, "方案", text)
        prev_art = self.artifact_of(p, r - 1)
        aid = self.p.next_id("artifacts", "A", "artifact_id")
        ev = self.p.log(p, "提交产物", round_=r, ref_type="artifact", ref_id=aid,
                        content={"file": path, "output_hash": h})
        self.p.exec("INSERT INTO artifacts VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (aid, p, r, "方案", path, h, canonical_json(delivered),
                     prev_art["output_hash"] if prev_art else "无", ev, "有效"))

        # 提交检查（第 3 步）：块编号、出处、原句、数字
        prev_fields = {b["item_id"]: b["fields"] for b in self.blocks_of(p, r - 1)}
        changed = 0
        n = 0
        for b in prod["blocks"]:
            n += 1
            bid = f"{p}-R{r}-B{n:03d}"
            f = b["fields"]
            flags = []
            st_check = "未查证"
            src = str(f.get("出处", "")).strip()
            if f["状态"] == "资料缺载":
                st_check = "未查证"
                flags.append("生产者称资料缺载")
            elif src == "模型记忆":
                flags.append("来源为模型记忆，标未查证")
            else:
                row = self.p.q("SELECT * FROM retrievals WHERE retrieval_id=?", (src,))
                if not row:
                    st_check = "出处无法解析"
                    flags.append(f"出处 {src} 不是已登记的检索编号")
                elif row[0]["source"] not in ("原文", "接口提取正文"):
                    flags.append("出处只有检索片段，不是原文，不能作为引文来源")
                else:
                    found, offset, para, ctx = B.locate_quote(self.p.read_archive(src), f.get("原句", ""))
                    if not found:
                        flags.append("原句未在所注检索的存档原文中找到")
                    else:
                        st_check = "待审查"
                        f["_位置"] = offset
                        date = T.normalize_date(f.get("出生日期"))
                        qnums = B.numbers_in(f.get("原句", ""))
                        if date and not any(int(x) == date[0] for x in qnums if x == int(x)):
                            flags.append("出生年份的数字未出现在原句中")
            flags += B.flag_notes(prod.get("notes", "")) if n == 1 else []
            if prev_fields.get(b["item"]) != canonical_json({k: v for k, v in f.items() if not k.startswith("_")}):
                changed += 1
            stored = {k: v for k, v in f.items() if not k.startswith("_")}
            self.p.exec("INSERT INTO blocks VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (bid, aid, p, r, b["type"], b["item"], canonical_json(stored), st_check, "未验证",
                         None, "有效", "[]", json.dumps(flags, ensure_ascii=False)))
            self.p.log("程序", "提交检查", round_=r, ref_type="block", ref_id=bid,
                       content={"查证": st_check, "标记": flags})

        # 意见处理（采纳门）
        for resp in prod.get("responses", []) or []:
            op = self.p.q("SELECT * FROM opinions WHERE opinion_id=? AND target_author=?", (resp.get("opinion"), p))
            ev_ok = self.p.q("SELECT 1 FROM retrievals WHERE retrieval_id=? AND item_id=?",
                             (resp.get("evidence"), op[0]["item_id"])) if op else []
            if op and op[0]["status"] in ("提出", "核验中") and ev_ok:
                self.p.exec("UPDATE opinions SET status=?, closed_round=?, evidence=? WHERE opinion_id=?",
                            (resp["action"], r, resp["evidence"], resp["opinion"]))
                self.p.log(p, "意见处理", round_=r, ref_type="opinion", ref_id=resp["opinion"],
                           content={"处理": resp["action"], "核验记录": resp["evidence"], "理由": resp.get("reason")})
            else:
                self.p.log("程序", "拒收", round_=r, ref_type="opinion", ref_id=resp.get("opinion"),
                           content={"原因": "意见处理未附该条目下有效的检索编号，意见保持未闭合"})
        total = max(len(prod["blocks"]), len(prev_fields)) or 1
        self._novelty[p] = (changed, changed / total)

    # ---------------- 审查 ----------------
    def review(self, rv, p, r):
        bl = [b for b in self.blocks_of(p, r) if b["st_check"] == "待审查"]
        if not bl:
            return
        view = []
        for b in bl:
            f = json.loads(b["fields"])
            _, _, para, ctx = B.locate_quote(self.p.read_archive(f["出处"]), f.get("原句", ""))
            url = self.p.q("SELECT url FROM retrievals WHERE retrieval_id=?", (f["出处"],))[0]["url"]
            view.append({"block": b["block_id"], "item": b["item_id"], "人物": f.get("人物"),
                         "出生日期": f.get("出生日期"), "农历原文": f.get("农历原文"), "原句": f.get("原句"),
                         "出处": f["出处"], "来源网址": url, "原文前后文": ctx or para})
        size = self.s["params"]["items_per_call"]
        res = {"reviews": []}
        for k in range(0, len(view), size):
            part_v = view[k:k + size]
            ids = [x["block"] for x in part_v]
            part = self.hub.call_json(rv, T.SYSTEM_REVIEWER, T.review_prompt(self.cfg, p, part_v),
                                      call_key=f"R{r}-{rv}-review-{p}-{k // size + 1}", round_=r,
                                      validator=lambda o, ids=ids: T.validate_review(o, ids))
            res["reviews"] += part["reviews"]
        same = int(self.series(rv) == self.series(p))
        for x in res["reviews"]:
            b = next(bb for bb in bl if bb["block_id"] == x["block"])
            rid = self.p.next_id("reviews", "V", "review_id")
            oid = None
            if x["verdict"] in ("错误", "需补充"):
                oid = self.p.next_id("opinions", "O", "opinion_id")
                self.p.exec("INSERT INTO opinions VALUES (?,?,?,?,?,?,?,?,?,?)",
                            (oid, rv, rid, p, b["item_id"],
                             f"审查判定{x['verdict']}：{x.get('reason', '')}；建议：{x.get('suggestion', '')}",
                             "提出", None, None, "审查"))
            self.p.exec("INSERT INTO reviews VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (rid, rv, b["artifact_id"], p, r, same, b["item_id"], b["block_id"], x["verdict"],
                         x.get("severity"), "检索核对", b["block_id"], x.get("reason", ""), 1, oid))
            self.p.log(rv, "审查意见", round_=r, ref_type="review", ref_id=rid,
                       content={"块": b["block_id"], "判定": x["verdict"], "同模型审查": bool(same),
                                "意见": oid})

    def apply_reviews(self, r):
        """全部审查者判完后，按块汇总：任一"错误/需补充"→未查证；否则任一"无法判断"→待核验；
        全部"正确"→已查证（含模型判断）。多名审查者之间取最低（0.4.6），与判定先后无关。"""
        for b in self.p.q("SELECT block_id FROM blocks WHERE round=? AND st_check='待审查'", (r,)):
            vs = self.p.q("SELECT verdict, same_model FROM reviews WHERE block_id=? AND round=?",
                          (b["block_id"], r))
            if not vs:
                continue
            verdicts = {v["verdict"] for v in vs}
            if verdicts & {"错误", "需补充"}:
                self.p.exec("UPDATE blocks SET st_check='未查证' WHERE block_id=?", (b["block_id"],))
            elif "无法判断" in verdicts:
                self.p.exec("UPDATE blocks SET st_verify='待核验' WHERE block_id=?", (b["block_id"],))
            else:
                self.p.exec("UPDATE blocks SET st_check='已查证（含模型判断）' WHERE block_id=?", (b["block_id"],))
                if all(v["same_model"] for v in vs):
                    self.p.exec("UPDATE blocks SET st_indep='仅同模型审查' WHERE block_id=?", (b["block_id"],))

    # ---------------- 状态更新 ----------------
    def _add_opinion(self, r, target, item, kind, content):
        """程序提出的意见按（对象, 条目, 种类）去重。"""
        dup = self.p.q("SELECT 1 FROM opinions WHERE target_author=? AND item_id=? AND kind=? "
                       "AND status IN ('提出','核验中')", (target, item, kind))
        if dup:
            return
        oid = self.p.next_id("opinions", "O", "opinion_id")
        self.p.exec("INSERT INTO opinions VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (oid, "程序", None, target, item, content, "提出", None, None, kind))
        self.p.log("程序", "意见提出", round_=r, ref_type="opinion", ref_id=oid, content={"内容": content})

    def _close_opinions(self, r, target, item, kinds, why):
        rows = self.p.q("SELECT opinion_id FROM opinions WHERE target_author=? AND item_id=? AND "
                        f"kind IN ({','.join('?' * len(kinds))}) AND status IN ('提出','核验中')",
                        (target, item, *kinds))
        for o in rows:
            self.p.exec("UPDATE opinions SET status='已解决', closed_round=? WHERE opinion_id=?", (r, o["opinion_id"]))
            self.p.log("程序", "意见闭合", round_=r, ref_type="opinion", ref_id=o["opinion_id"], content={"依据": why})

    def _source_key(self, retrieval_id):
        from urllib.parse import urlparse
        row = self.p.q("SELECT url, content_hash FROM retrievals WHERE retrieval_id=?", (retrieval_id,))[0]
        return urlparse(row["url"] or "").netloc.lower(), row["content_hash"]

    def update_state(self, r):
        terminal = True
        for it in self.items:
            iid = it["id"]
            latest = {p: next((b for b in self.blocks_of(p, r) if b["item_id"] == iid), None) for p in self.producers}
            ok = {p: b for p, b in latest.items() if b and b["st_check"].startswith("已查证")}
            # 新块已通过查证：该生产者在此条目上的审查意见与"未通过查证"意见自动闭合（依据可机械核对）
            for p in ok:
                self._close_opinions(r, p, iid, ["审查", "未通过查证"], f"{ok[p]['block_id']} 已通过查证")
            dates = {p: T.normalize_date(json.loads(b["fields"]).get("出生日期")) for p, b in ok.items()}
            dates = {p: d for p, d in dates.items() if d}
            series = {self.series(p) for p in dates}
            states = {p: json.loads(b["fields"])["状态"] for p, b in latest.items() if b}
            if len(dates) >= 2 and len(set(dates.values())) == 1:
                d = next(iter(dates.values()))
                keys = [self._source_key(json.loads(ok[p]["fields"])["出处"]) for p in dates]
                domains, hashes = {k[0] for k in keys}, {k[1] for k in keys}
                if len(series) < 2:
                    indep, count, note = "未独立验证", 0, "各方查证一致，但各方模型属同一系列，不计独立验证"
                elif len(domains) >= 2 and len(hashes) >= 2:
                    indep, count, note = "独立", len(series) - 1, "各方查证一致，来源网站互不相同"
                else:
                    indep, count, note = "独立性未确认", 0, "各方查证一致，但引用同一网站或同一原文，不计独立验证"
                for p in dates:
                    self._close_opinions(r, p, iid, ["分歧"], "各方已查证结果一致")
                self._set_item(r, iid, "已查证（含模型判断）", "已验证", indep, count, T.format_date(d), note)
            elif len(set(dates.values())) >= 2:
                settled = all(states.get(p) == "有争议" and json.loads(ok[p]["fields"]).get("异说") for p in dates)
                terminal = terminal and settled
                desc = "；".join(f"{p}：{json.loads(ok[p]['fields'])['出生日期']}（{json.loads(ok[p]['fields'])['出处']}）"
                                for p in dates)
                for p in dates:
                    if settled:
                        self._close_opinions(r, p, iid, ["分歧"], "各方已如实登记为有争议并列出异说")
                    else:
                        self._add_opinion(r, p, iid, "分歧",
                                          f"条目 {iid} 各方已查证的出生日期不一致（{desc}），请复核来源；"
                                          f"确属来源分歧的，状态填有争议并在异说中列出另一说法")
                self._set_item(r, iid, "已查证（含模型判断）", "待核验", None, 0, None,
                               ("有争议（来源分歧，已列异说）：" if settled else "有争议（待复核）：") + desc)
            elif states and all(s == "资料缺载" for s in states.values()):
                self._set_item(r, iid, "未查证", "未验证", None, 0, "资料缺载", "各方均称资料缺载")
            else:
                terminal = False
                for p, b in latest.items():
                    if p not in dates:
                        self._add_opinion(r, p, iid, "未通过查证",
                                          f"条目 {iid}：你的条目块未通过查证（{b['st_check'] if b else '缺失'}），"
                                          f"请重新检索并从原文逐字摘抄原句；确实查不到的如实填资料缺载")
                self._set_item(r, iid, "未查证", "未验证", None, 0, None,
                               f"已通过查证的生产者：{sorted(dates) or '无'}")
        open_n = self.p.q("SELECT COUNT(*) c FROM opinions WHERE status IN ('提出','核验中')")[0]["c"]
        new_err = self.p.q("SELECT COUNT(*) c FROM reviews WHERE round=? AND verdict='错误'", (r,))[0]["c"]
        nov = self._novelty
        changed = sum(v[0] for v in nov.values())
        ratio = (sum(v[1] for v in nov.values()) / len(nov)) if nov else 0
        low = int(r > 1 and ratio < 0.10 and changed < 1)
        self.p.exec("INSERT OR REPLACE INTO round_stats VALUES (?,?,?,?,?,?,?)",
                    (r, new_err, open_n, changed, round(ratio, 4), low, None))
        self.p.log("程序", "状态更新", round_=r,
                   content={"未闭合意见": open_n, "新发现错误": new_err, "改动块": changed, "低新颖": bool(low)})
        return terminal and open_n == 0

    def _set_item(self, r, iid, st_check, st_verify, st_indep, count, value, note):
        row = self.p.q("SELECT history FROM items WHERE item_id=?", (iid,))[0]
        hist = json.loads(row["history"])
        hist.append({"round": r, "查证": st_check, "验证": st_verify, "独立性": st_indep,
                     "独立验证次数": count, "值": value, "说明": note})
        self.p.exec("UPDATE items SET st_check=?,st_verify=?,st_indep=?,indep_count=?,value=?,note=?,history=? "
                    "WHERE item_id=?", (st_check, st_verify, st_indep, count, value, note,
                                        json.dumps(hist, ensure_ascii=False), iid))
