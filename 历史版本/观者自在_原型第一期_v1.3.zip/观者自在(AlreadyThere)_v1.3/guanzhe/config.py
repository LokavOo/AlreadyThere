"""读取设置与密钥。

- settings.json：模型接入、角色分配、流程参数（可以公开，不含密钥）。
- secrets.env：密钥，每行 名称=值。只由用户自己填写，程序只读取，不写入账本。
"""

from __future__ import annotations

import json
import os
from pathlib import Path

DEFAULT_PARAMS = {
    # 0.3 调用失败重试（草案初始值）
    "retry_batch1": [10, 10, 10],
    "retry_batch2": [60, 120, 240],
    "call_timeout_seconds": 300,          # 原型前须实测；先给一个宽松值
    # 流程
    "max_rounds": 4,                      # 原型第一期用较小的上限
    "search_results_per_query": 3,
    "items_per_call": 6,                 # 每次调用处理的条目数，控制输入长度
    "max_sources_shown": 4,              # 每个条目最多展示的检索来源数
}


def load_secrets(path: str | os.PathLike | None) -> dict:
    secrets = {}
    if path and Path(path).exists():
        for line in Path(path).read_text(encoding="utf-8-sig").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            secrets[k.strip()] = v.strip().strip('"').strip("'")
    # 环境变量优先
    for k in list(secrets) + ["ANTHROPIC_API_KEY", "DEEPSEEK_API_KEY", "DASHSCOPE_API_KEY",
                              "ARK_API_KEY", "TAVILY_API_KEY"]:
        if os.environ.get(k):
            secrets[k] = os.environ[k]
    return secrets


def load_settings(path: str | os.PathLike) -> dict:
    s = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    params = dict(DEFAULT_PARAMS)
    params.update(s.get("params", {}))
    s["params"] = params
    return s
