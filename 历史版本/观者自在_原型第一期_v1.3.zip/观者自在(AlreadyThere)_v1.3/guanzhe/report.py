"""输出物（第 10 节）第一期：结论 + 全流程记录索引。论文与专家审阅页属第三期。"""

from __future__ import annotations

import json
from pathlib import Path

from .tasks import fact_compilation as T


def build(project):
    items = [dict(r) for r in project.q("SELECT * FROM items ORDER BY item_id")]
    group_of = {x["id"]: x.get("group") for x in project.config.get("items", [])}  # 1.2：条目可带分组（如朝代）
    rows, results = [], []
    for it in items:
        if it["st_verify"] == "已验证":
            state = "查到"
        elif it["value"] == "资料缺载":
            state = "资料缺载"
        elif (it["note"] or "").startswith("有争议"):
            state = "有争议"
        else:
            state = "未得出"
        z, why = (None, "未得到已验证的出生日期")
        if state == "查到":
            z, why = T.zodiac_of(T.normalize_date(it["value"]))
        results.append((it["item_id"], z))
        rows.append({"条目": it["item_id"], "分组": group_of.get(it["item_id"]), "人物": it["name"], "结论": state, "出生日期": it["value"],
                     "查证": it["st_check"], "验证": it["st_verify"], "独立性": it["st_indep"],
                     "独立验证次数": it["indep_count"], "生肖": z, "生肖说明": why, "备注": it["note"]})
    stats = T.tally(results)
    ok, bad, n = project.verify_chain()
    counts = [r["indep_count"] for r in items if r["st_verify"] == "已验证"]
    conclusion = {
        "问题": project.config["question"],
        "口径": project.config["scope"],
        "逐条结果": rows,
        "生肖统计（由代码计算，只计已验证且能确定生肖者）": stats,
        "独立验证次数最小值（已验证条目）": min(counts) if counts else None,
        "说明": ["查证维度中的'含模型判断'指：原句在所注原文位置由程序核对；原文是否支持该日期由审查者判断。",
               "生肖按公历日期推算；生于公历 1 月 1 日至 3 月 2 日之间者须核对农历，未计入统计。",
               "第一期未实现找茬者与准入门；结论不含找茬环节。"],
        "账本完整性": {"完整": ok, "第一个不一致事件": bad, "事件数": n},
    }
    out = project.root / "outputs"
    out.mkdir(exist_ok=True)
    (out / "结论.json").write_text(json.dumps(conclusion, ensure_ascii=False, indent=2), encoding="utf-8")
    md = [f"# 结论：{conclusion['问题']}", "", f"口径：{conclusion['口径']}"]
    groups = []
    for r in rows:
        if r["分组"] not in groups:
            groups.append(r["分组"])
    for g in groups:
        md += ["", f"## {g}" if g else "## 逐条结果", "",
               "| 条目 | 人物 | 结论 | 出生日期 | 独立验证次数 | 生肖 | 说明 |", "|---|---|---|---|---|---|---|"]
        for r in rows:
            if r["分组"] != g:
                continue
            md.append(f"| {r['条目']} | {r['人物']} | {r['结论']} | {r['出生日期'] or ''} | {r['独立验证次数']} | "
                      f"{r['生肖'] or ''} | {r['生肖说明']}；{r['备注'] or ''} |")
    md += ["", "## 生肖统计（全部分组合计）"]
    md += ["", f"已确定生肖：{stats['已确定生肖人数']} 人；未能确定：{stats['未能确定人数']} 人", "",
           "| 生肖 | 人数 | 占已确定者比例 |", "|---|---|---|"]
    md += [f"| {g['生肖']} | {g['人数']} | {g['占已确定者比例'] if g['占已确定者比例'] is not None else ''} |"
           for g in stats["分组"]]
    md += ["", "说明："] + [f"- {x}" for x in conclusion["说明"]]
    md += ["", f"账本完整性：{'完整' if ok else '不完整，第一个不一致事件 ' + str(bad)}（共 {n} 条事件）"]
    (out / "结论.md").write_text("\n".join(md), encoding="utf-8")
    project.log("程序", "输出结论", content={"file": "outputs/结论.json"})
    return conclusion
