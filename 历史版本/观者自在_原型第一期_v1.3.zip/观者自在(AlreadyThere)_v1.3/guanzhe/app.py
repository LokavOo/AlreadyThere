"""窗口版（1.3）：本机小服务 + 应用窗口（Edge 应用模式，没有地址栏）。

只监听 127.0.0.1，别的电脑访问不到。密钥只在本机读取，页面上只显示"已填/未填"，不显示内容。
运行、连通测试都在独立的子进程里进行，输出写进项目文件夹里的"运行日志.txt"；
关掉窗口不会打断正在进行的运行，重新打开窗口可以接着看。
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import feed
from .config import load_secrets, load_settings

SETTINGS = "设置.json"
SECRETS = "密钥.env"
LOCK = "运行中.txt"
LOG = "运行日志.txt"
SAFE = re.compile(r"^[^\\/:*?\"<>|]{1,60}$")
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _py():
    """子进程用带控制台输出的 python.exe（pythonw 打印不了东西）。"""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").exists():
        return str(exe.parent / "python.exe")
    return sys.executable


def _alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        k.GetExitCodeProcess(h, ctypes.byref(code))
        k.CloseHandle(h)
        return code.value == 259  # STILL_ACTIVE
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


class App:
    def __init__(self, base: Path):
        self.base = Path(base)
        self.ping_lines: list[str] = []
        self.ping_running = False
        self.last_beat = time.time()

    # ---------- 状态 ----------
    def running_pid(self, proj: Path) -> int:
        f = proj / LOCK
        if f.exists():
            try:
                pid = int(f.read_text(encoding="utf-8").split()[0])
            except (ValueError, IndexError):
                pid = 0
            if _alive(pid):
                return pid
            f.unlink(missing_ok=True)
        return 0

    def projects(self):
        out = []
        for d in sorted(self.base.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
            if d.is_dir() and (d / "project.db").exists():
                done = (d / "outputs" / "结论.md").exists()
                out.append({"name": d.name, "running": bool(self.running_pid(d)), "done": done})
        return out

    def questions(self):
        out = []
        for f in sorted(self.base.glob("*.json")):
            if f.name == SETTINGS:
                continue
            try:
                obj = json.loads(f.read_text(encoding="utf-8-sig"))
            except (OSError, ValueError):
                continue
            if isinstance(obj, dict) and "items" in obj and "question" in obj:
                out.append({"file": f.name, "question": obj["question"], "count": len(obj["items"])})
        return out

    def state(self):
        roles, err = [], None
        try:
            st = load_settings(self.base / SETTINGS)
            sec = load_secrets(self.base / SECRETS)
            for r, s in st["roles"].items():
                roles.append({"role": r, "name": s.get("series", r), "model": s.get("model", ""),
                              "kind": s.get("kind", ""), "key": bool(sec.get(s.get("key_name", "")))})
            sk = st.get("search", {}).get("key_name", "TAVILY_API_KEY")
            search_key = bool(sec.get(sk))
        except FileNotFoundError as e:
            err, search_key = f"找不到文件：{Path(str(e.filename)).name}", False
        except ValueError as e:
            err, search_key = f"设置文件格式有误：{e}", False
        return {"roles": roles, "search_key": search_key, "secrets_file": (self.base / SECRETS).exists(),
                "error": err, "projects": self.projects(), "questions": self.questions(),
                "ping": {"running": self.ping_running, "lines": self.ping_lines[-40:]}}

    # ---------- 动作 ----------
    def ping(self):
        if self.ping_running:
            return {"ok": False, "msg": "连通测试正在进行"}
        self.ping_running, self.ping_lines = True, ["开始连通测试……"]

        def work():
            try:
                p = subprocess.Popen([_py(), "-m", "guanzhe", "ping", "--settings", SETTINGS, "--secrets", SECRETS],
                                     cwd=self.base, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     env=dict(os.environ, PYTHONIOENCODING="utf-8"), creationflags=NOWIN)
                for raw in p.stdout:
                    self.ping_lines.append(raw.decode("utf-8", "replace").rstrip())
                p.wait()
                self.ping_lines.append("连通测试结束。")
            except OSError as e:
                self.ping_lines.append(f"没能启动连通测试：{e}")
            finally:
                self.ping_running = False
        threading.Thread(target=work, daemon=True).start()
        return {"ok": True}

    def new_project(self, name: str, qfile: str):
        if not SAFE.match(name or "") or name.startswith("."):
            return {"ok": False, "msg": "项目名不能为空，也不能含 \\ / : * ? \" < > | 这些符号"}
        if (self.base / name / "project.db").exists():
            return {"ok": False, "msg": f"已经有叫「{name}」的项目了，换个名字"}
        if qfile == "__demo__":
            args = ["demo", name]
        else:
            if not (self.base / qfile).exists():
                return {"ok": False, "msg": "找不到这个题目文件"}
            args = ["new", name, "--project", qfile]
        r = subprocess.run([_py(), "-m", "guanzhe", *args], cwd=self.base, capture_output=True,
                           env=dict(os.environ, PYTHONIOENCODING="utf-8"), creationflags=NOWIN)
        out = (r.stdout + r.stderr).decode("utf-8", "replace").strip()
        if r.returncode != 0:
            return {"ok": False, "msg": out[-400:] or "创建失败"}
        return {"ok": True, "name": name}

    def run(self, name: str):
        proj = self.base / name
        if not (proj / "project.db").exists():
            return {"ok": False, "msg": "找不到这个项目"}
        if self.running_pid(proj):
            return {"ok": False, "msg": "这个项目已经在运行了"}
        log = open(proj / LOG, "ab")
        log.write(f"\n==== {time.strftime('%Y-%m-%d %H:%M:%S')} 开始运行 ====\n".encode("utf-8"))
        log.flush()
        p = subprocess.Popen([_py(), "-m", "guanzhe", "run", name, "--settings", SETTINGS, "--secrets", SECRETS],
                             cwd=self.base, stdout=log, stderr=subprocess.STDOUT,
                             env=dict(os.environ, PYTHONIOENCODING="utf-8"), creationflags=NOWIN)
        (proj / LOCK).write_text(f"{p.pid}\n", encoding="utf-8")

        def reap():
            p.wait()
            log.close()
            (proj / LOCK).unlink(missing_ok=True)
        threading.Thread(target=reap, daemon=True).start()
        return {"ok": True}

    def log_tail(self, name: str):
        f = self.base / name / LOG
        if not f.exists():
            return ""
        return f.read_bytes()[-3000:].decode("utf-8", "replace")

    def conclusion(self, name: str):
        f = self.base / name / "outputs" / "结论.md"
        return f.read_text(encoding="utf-8-sig") if f.exists() else None

    def detail(self, name: str):
        port = 8800 + (abs(hash(name)) % 150)
        subprocess.Popen([_py(), "-m", "guanzhe", "serve", name, "--port", str(port)], cwd=self.base,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NOWIN)
        return {"ok": True, "url": f"http://127.0.0.1:{port}/"}


def make_handler(app: App):
    page = (Path(__file__).parent / "app_page.html").read_text(encoding="utf-8")

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, body, ctype="application/json; charset=utf-8", code=200):
            data = body if isinstance(body, bytes) else (
                body.encode("utf-8") if isinstance(body, str) else json.dumps(body, ensure_ascii=False).encode("utf-8"))
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _proj(self, q):
            name = (q.get("p") or [""])[0]
            if not SAFE.match(name) or not (app.base / name / "project.db").exists():
                return None
            return name

        def do_GET(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            app.last_beat = time.time()
            if u.path == "/":
                return self._send(page, "text/html; charset=utf-8")
            if u.path == "/api/state":
                return self._send(app.state())
            if u.path == "/api/feed":
                name = self._proj(q)
                if not name:
                    return self._send({"messages": [], "last": 0, "running": False})
                after = int((q.get("after") or ["0"])[0] or 0)
                r = feed.messages(app.base / name, after)
                r["running"] = bool(app.running_pid(app.base / name))
                r["log"] = app.log_tail(name) if not r["running"] else ""
                try:
                    r["question"] = json.loads((app.base / name / "config.json").read_text(encoding="utf-8-sig"))["question"]
                except (OSError, ValueError, KeyError):
                    r["question"] = ""
                return self._send(r)
            if u.path == "/api/conclusion":
                name = self._proj(q)
                return self._send({"text": app.conclusion(name) if name else None})
            self._send({"error": "not found"}, code=404)

        def do_POST(self):
            u = urlparse(self.path)
            n = int(self.headers.get("Content-Length") or 0)
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                body = {}
            if self.headers.get("X-Guanzhe") != "1":  # 只接受本窗口发来的请求
                return self._send({"ok": False, "msg": "拒绝"}, code=403)
            if u.path == "/api/ping":
                return self._send(app.ping())
            if u.path == "/api/new":
                return self._send(app.new_project(str(body.get("name", "")).strip(), str(body.get("question", ""))))
            if u.path == "/api/run":
                return self._send(app.run(str(body.get("name", ""))))
            if u.path == "/api/detail":
                return self._send(app.detail(str(body.get("name", ""))))
            self._send({"error": "not found"}, code=404)
    return H


def open_window(url: str):
    if os.name == "nt":
        for exe in [os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
                    os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
                    os.path.expandvars(r"%LocalAppData%\Microsoft\Edge\Application\msedge.exe")]:
            if Path(exe).exists():
                subprocess.Popen([exe, f"--app={url}", "--window-size=1180,820"], creationflags=NOWIN)
                return
    webbrowser.open(url)


def main(base=".", port=0, open_it=True, idle_exit=True):
    app = App(Path(base).resolve())
    srv = ThreadingHTTPServer(("127.0.0.1", port), make_handler(app))
    url = f"http://127.0.0.1:{srv.server_address[1]}/"
    print(f"观者自在 窗口地址：{url}")
    if open_it:
        open_window(url)
    if idle_exit:  # 窗口关掉 60 秒后自动退出（正在进行的运行不受影响）
        def watch():
            while True:
                time.sleep(10)
                if time.time() - app.last_beat > 60:
                    srv.shutdown()
                    return
        threading.Thread(target=watch, daemon=True).start()
    srv.serve_forever()
