"""事实汇编规则包（11.3）：以"历代皇帝出生日期 → 生肖分组统计"为试跑任务。

口径由用户在项目配置中给定（条目清单 + 口径说明）。
每个条目由各生产者独立检索、独立撰写一个"条目块"；生肖归类、计数、占比全部由代码完成。
"""

from __future__ import annotations

import re
from collections import Counter

from ..util import canonical_json

ZODIAC = "鼠牛虎兔龙蛇马羊猴鸡狗猪"

BLOCK_SCHEMA = {
    # 条目块：状态为 查到 时须附出处与原句；资料缺载 时出生日期填"资料缺载"
    "条目": ["人物", "出生日期", "状态"],
}

ENTRY_STATES = ("查到", "有争议", "资料缺载")

SYSTEM_PRODUCER = """你是多模型互查流程中的"生产者"。任务是事实汇编：为每个条目查出人物的出生日期，并给出出处。
规则（必须遵守）：
1. 只能引用程序提供的检索原文；出处填检索编号（形如 S00012），原句必须从该检索原文中逐字摘抄。
2. 查不到就如实填"资料缺载"，不得凭记忆编造；如果只能凭记忆给出，出处填"模型记忆"（会被标为未查证）。
3. 不同来源说法不一致时，状态填"有争议"，并在 fields.异说 中列出另一说法及其检索编号。
4. 出生日期写成公历 YYYY-MM-DD；原文只有年份的写 YYYY；原文是农历的，照原文写入 fields.农历原文，出生日期写能确定的部分。
5. 只输出一个 JSON 对象，不要输出其他文字。不要在说明文字中声称"已验证""已核对"。"""

SYSTEM_REVIEWER = """你是多模型互查流程中的"审查者"。你逐条核对生产者提交的条目块：
程序已经确认原句确实出现在所注的检索原文中；你要判断的是：这句原文（结合前后文）是否支持"该人物的出生日期为所填值"。
判定只能是：正确 / 错误 / 需补充 / 无法判断。错误或需补充时写明理由与建议。
只输出一个 JSON 对象，不要输出其他文字。"""


def search_prompt(config, items, own_prev=None, opinions=None):
    lines = [f"口径：{config['scope']}", "", "条目清单："]
    lines += [f"- {it['id']}：{it['name']}" for it in items]
    if opinions:
        lines += ["", "针对你的未闭合意见："] + [f"- {o['opinion_id']}（条目 {o['item_id']}）：{o['content']}" for o in opinions]
    lines += ["", "请为需要检索的条目给出检索词（每个条目最多 2 个）。已有可靠出处、且没有针对它的意见的条目可以不检索。",
              '输出格式：{"searches": [{"item": "I01", "query": "检索词"}]}']
    return "\n".join(lines)


def excerpts_for(project, retrieval_ids, name, max_chars=500):
    """从存档原文中截取含人物名的段落，标注检索编号，供生产者撰写（截取规则由程序确定，不由模型决定）。"""
    out = []
    for rid in retrieval_ids:
        text = project.read_archive(rid) or ""
        row = project.q("SELECT url,title,source FROM retrievals WHERE retrieval_id=?", (rid,))[0]
        paras = [p.strip() for p in re.split(r"\n+", text) if p.strip()]
        key = name[-2:] if len(name) >= 2 else name
        hits = [p for p in paras if name in p or key in p]
        hits = sorted(hits, key=lambda p: ("生" not in p and "诞" not in p, len(p)))[:2]
        body = "\n".join(h[:max_chars] for h in hits) if hits else "（原文中未出现该人物名）"
        out.append(f"【{rid}】{row['title']} {row['url']}（{row['source']}）\n{body}")
    return "\n\n".join(out)


def write_prompt(config, items, evidence_by_item, round_, own_prev=None, others=None, opinions=None):
    lines = [f"第 {round_} 轮。口径：{config['scope']}", ""]
    for it in items:
        lines.append(f"==== 条目 {it['id']}：{it['name']} ====")
        lines.append(evidence_by_item.get(it["id"]) or "（本轮无新检索结果）")
        lines.append("")
    if own_prev:
        lines += ["你上一轮提交的条目块：", canonical_json(own_prev), ""]
    if others:
        lines += ["其他生产者上一轮的条目块（仅供对照；不得直接照抄他方结果，引用须来自你自己核对过的原文）：",
                  canonical_json(others), ""]
    if opinions:
        lines += ["针对你的未闭合意见（须逐条在 responses 中处理：采纳或驳回，并附检索编号作为核验记录）："]
        lines += [f"- {o['opinion_id']}（条目 {o['item_id']}）：{o['content']}" for o in opinions]
        lines.append("")
    lines += [
        "请为每个条目提交一个条目块。输出格式：",
        '{"blocks": [{"type": "条目", "item": "I01", "fields": {"人物": "…", "出生日期": "YYYY-MM-DD 或 YYYY 或 资料缺载",'
        ' "状态": "查到/有争议/资料缺载", "出处": "S00012 或 模型记忆", "原句": "从原文逐字摘抄", "农历原文": "（如有）",'
        ' "异说": "（有争议时填写）"}}],',
        ' "notes": "简短说明，不含需检查的主张",',
        ' "changes": [{"type": "数值/判据/结论/措辞", "item": "I01", "说明": "…"}],',
        ' "responses": [{"opinion": "O00001", "action": "采纳/驳回", "evidence": "S00012", "reason": "…"}]}',
        "第 1 轮 changes 与 responses 可以为空数组。",
    ]
    return "\n".join(lines)


def review_prompt(config, author_role, blocks_view):
    lines = [f"口径：{config['scope']}", f"被审产物作者：{author_role}", "",
             "逐条核对以下条目块。每条已附程序从存档中取出的原句所在段落及前后文：", ""]
    for b in blocks_view:
        lines.append(canonical_json(b))
    lines += ["", '输出格式：{"reviews": [{"block": "块编号", "verdict": "正确/错误/需补充/无法判断",'
              ' "severity": "阻断/必改/小修（判定非正确时）", "reason": "理由", "suggestion": "建议（可空）"}]}']
    return "\n".join(lines)


def validate_review(obj, block_ids):
    from ..util import FormatError
    if not isinstance(obj.get("reviews"), list):
        raise FormatError("缺少 reviews 数组")
    seen = set()
    for r in obj["reviews"]:
        if not isinstance(r, dict):
            raise FormatError("reviews 的每一项须是 JSON 对象")
        if r.get("block") not in block_ids:
            raise FormatError(f"reviews 中的块编号 {r.get('block')!r} 不存在")
        if r.get("verdict") not in ("正确", "错误", "需补充", "无法判断"):
            raise FormatError(f"verdict {r.get('verdict')!r} 不合规")
        seen.add(r["block"])
    missing = set(block_ids) - seen
    if missing:
        raise FormatError(f"以下块没有给出判定：{sorted(missing)}")


# ---------------- 由代码完成的计算 ----------------

_DATE = re.compile(r"^(\d{3,4})(?:-(\d{1,2})-(\d{1,2}))?$")


def normalize_date(s):
    m = _DATE.match(str(s or "").strip())
    if not m:
        return None
    y = int(m.group(1))
    if m.group(2):
        return (y, int(m.group(2)), int(m.group(3)))
    return (y, None, None)


def format_date(d):
    y, m, dd = d
    return f"{y}" if m is None else f"{y}-{m:02d}-{dd:02d}"


def zodiac_of(date):
    """由公历出生日期推算生肖。

    春节在公历 1 月 21 日至 2 月 20 日之间；古代日期还存在儒略历/格里历换算差异（约 10 天），
    因此把 1 月 1 日至 3 月 2 日定为"须核对农历"区间，不在此区间内的按公历年份推算。
    只知年份的，无法确定生肖。返回 (生肖或 None, 说明)。
    """
    if not date:
        return None, "无出生日期"
    y, m, d = date
    if m is None:
        return None, "仅知年份，无法确定生肖（须知月日或农历年）"
    if m == 1 or m == 2 or (m == 3 and d <= 2):
        return None, "生于公历 1 月 1 日至 3 月 2 日之间，须核对农历年"
    return ZODIAC[(y - 4) % 12], f"按公历 {y} 年推算（{y} 年春节后出生）"


def tally(results):
    """results: [(条目, 生肖或 None)] -> 统计表。"""
    known = [z for _, z in results if z]
    c = Counter(known)
    n = len(known)
    rows = [{"生肖": z, "人数": c.get(z, 0), "占已确定者比例": (round(c.get(z, 0) / n, 4) if n else None)}
            for z in ZODIAC]
    return {"已确定生肖人数": n, "未能确定人数": len(results) - n, "分组": rows}
