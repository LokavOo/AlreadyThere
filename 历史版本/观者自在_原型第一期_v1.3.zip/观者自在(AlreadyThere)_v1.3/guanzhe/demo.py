"""演示场景：模拟模型 + 模拟检索，不联网、不需要密钥、不花钱。

人物与网页内容均为虚构的测试夹具，不代表任何真实史实。场景中故意安排：
- 生产者 P2 第 1 轮对"测试乙帝"编造了一句原文里没有的原句（程序应标"原句未找到"并提出意见）；
- 两个来源对"测试丙帝"的出生日期说法不一（应登记为有争议并要求复核）；
- "测试丁帝"查不到资料（两方都应如实报资料缺载）。
"""

from __future__ import annotations

import json
import re

PAGES = [
    {"url": "https://example.test/jia", "title": "测试甲帝（虚构）", "keywords": ["甲帝"],
     "text": "测试甲帝是虚构人物。\n测试甲帝生于1500年10月3日，卒于1560年。\n其余内容略。"},
    {"url": "https://another.test/jia2", "title": "测试甲帝年表（虚构）", "keywords": ["甲帝"],
     "text": "年表：测试甲帝，1500年10月3日出生。"},
    {"url": "https://example.test/yi", "title": "测试乙帝（虚构）", "keywords": ["乙帝"],
     "text": "测试乙帝，虚构人物。\n测试乙帝生于1523年6月15日。"},
    {"url": "https://example.test/bing-a", "title": "测试丙帝甲说（虚构）", "keywords": ["丙帝"],
     "text": "测试丙帝生于1540年8月1日。"},
    {"url": "https://example.test/bing-b", "title": "测试丙帝乙说（虚构）", "keywords": ["丙帝"],
     "text": "另有记载：测试丙帝生于1541年8月1日。"},
]

ITEMS = [{"id": "I01", "name": "测试甲帝"}, {"id": "I02", "name": "测试乙帝"},
         {"id": "I03", "name": "测试丙帝"}, {"id": "I04", "name": "测试丁帝"}]


def _parse_evidence(user):
    """从撰写提示词里取出每个条目的检索编号和原文段落。"""
    ev = {}
    for sec in re.split(r"==== 条目 ", user)[1:]:
        iid = sec[:3]
        found = re.findall(r"【(S\d+)】[^\n]*\n([^【=]*)", sec)
        ev[iid] = [(rid, body.strip()) for rid, body in found]
    return ev


def _dates(text):
    return re.findall(r"(\d{4})年(\d{1,2})月(\d{1,2})日", text)


def producer(which):
    """which='P1' 或 'P2'。P2 在第 1 轮编造乙帝原句；两方对丙帝各取一个来源。"""

    def respond(model, system, user):
        if '"searches"' in user and "请为需要检索的条目给出检索词" in user:
            return json.dumps({"searches": [{"item": it["id"], "query": it["name"] + " 出生"} for it in ITEMS]},
                              ensure_ascii=False)
        rnd = int(re.search(r"第 (\d+) 轮", user).group(1))
        ev = _parse_evidence(user)
        ops = re.findall(r"- (O\d+)（条目 (I\d+)）", user)
        blocks = []
        for it in ITEMS:
            cands = [(rid, body) for rid, body in ev.get(it["id"], []) if _dates(body)]
            other = None
            if it["id"] == "I03" and len(cands) >= 2:
                cands, other = (cands[:1], cands[1]) if which == "P1" else (cands[1:], cands[0])
            if not cands:
                blocks.append({"type": "条目", "item": it["id"],
                               "fields": {"人物": it["name"], "出生日期": "资料缺载", "状态": "资料缺载"}})
                continue
            rid, body = cands[-1] if (which == "P2" and it["id"] == "I01") else cands[0]
            y, m, d = _dates(body)[0]
            line = next(l for l in body.splitlines() if _dates(l))
            quote = line.strip()
            if which == "P2" and it["id"] == "I02" and rnd == 1:
                quote = "据载测试乙帝降生于1523年6月15日辰时"  # 编造的原句
            fields = {"人物": it["name"], "出生日期": f"{y}-{int(m):02d}-{int(d):02d}",
                      "状态": "查到", "出处": rid, "原句": quote}
            if other and rnd >= 2:  # 复核后如实报有争议，列出异说
                fields["状态"] = "有争议"
                fields["异说"] = f"另一来源 {other[0]} 记为 " + "-".join(_dates(other[1])[0])
            blocks.append({"type": "条目", "item": it["id"], "fields": fields})
        responses = []
        for oid, iid in ops:
            rid = next((r for r, b in ev.get(iid, []) if _dates(b)), None)
            if rid:
                responses.append({"opinion": oid, "action": "采纳", "evidence": rid,
                                  "reason": "已重新核对原文并按原文摘抄"})
        return json.dumps({"blocks": blocks, "notes": "按口径逐条检索。",
                           "changes": [] if rnd == 1 else [{"type": "措辞", "item": "I02", "说明": "按原文重抄原句"}],
                           "responses": responses}, ensure_ascii=False)

    return respond


def reviewer(model, system, user):
    out = []
    for line in user.splitlines():
        if line.startswith("{") and '"block"' in line:
            b = json.loads(line)
            y = (b.get("出生日期") or "")[:4]
            ok = y and y in (b.get("原句") or "") and b.get("人物", "") in (b.get("原文前后文") or "")
            out.append({"block": b["block"], "verdict": "正确" if ok else "错误",
                        "reason": "原句所在段落明确写出该人物与该日期" if ok else "原文不支持该日期",
                        "severity": None if ok else "必改"})
    return json.dumps({"reviews": out}, ensure_ascii=False)


def settings():
    return {
        "roles": {
            "P1": {"kind": "生产者", "provider": "mock", "model": "mock-a", "series": "模拟A", "context_window": 100000},
            "P2": {"kind": "生产者", "provider": "mock", "model": "mock-b", "series": "模拟B", "context_window": 100000},
            "R1": {"kind": "审查者", "provider": "mock", "model": "mock-c", "series": "模拟C", "context_window": 100000},
        },
        "search": {"engine": "mock"},
        "params": {"retry_batch1": [0, 0, 0], "retry_batch2": [0, 0, 0], "max_rounds": 4},
    }


def project_config():
    return {"project_id": "DEMO", "question": "列出测试皇帝的出生日期，并按生肖分组统计（演示，虚构数据）",
            "scope": "条目清单由用户给定；出生日期以公历记；生肖由代码按公历日期推算",
            "items": ITEMS}


def providers():
    from .models import MockProvider
    return {"mock|": _Router()}


class _Router:
    """按模型名把调用分给不同的模拟角色。"""

    def __init__(self):
        self.map = {"mock-a": producer("P1"), "mock-b": producer("P2"), "mock-c": reviewer}

    def complete(self, model, system, user, max_tokens, timeout):
        text = self.map[model](model, system, user)
        return text, len(system + user) // 2, len(text) // 2
