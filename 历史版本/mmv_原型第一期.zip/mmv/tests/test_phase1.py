"""第一期测试：python -m unittest discover -s tests"""

import json
import shutil
import sqlite3
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

from mmv import demo, report
from mmv.__main__ import load_settings_from_obj
from mmv.blocks import locate_quote
from mmv.flow import Flow
from mmv.models import CallFailedPause, FatalCallError, ModelHub, TransportError
from mmv.retrieval import MockSearch, Retriever
from mmv.store import Project
from mmv.tasks.fact_compilation import normalize_date, zodiac_of
from mmv.util import extract_json, find_numbers, written_matches_output


class Tmp(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def demo_project(self, name="p"):
        p = Project.create(self.dir / name, demo.project_config())
        st = load_settings_from_obj(demo.settings())
        return p, st


class TestUtil(unittest.TestCase):
    def test_numbers(self):
        vals = dict(find_numbers("约四成，62%，0.62，一三二八年"))
        self.assertIsNone(vals["四"] if "四" in vals else None)
        self.assertEqual(vals["62%"], Decimal("0.62"))
        self.assertEqual(vals["一三二八"], Decimal(1328))

    def test_written_precision(self):
        self.assertTrue(written_matches_output("0.333", 0.333333))
        self.assertFalse(written_matches_output("0.34", 0.333333))

    def test_extract_json(self):
        self.assertEqual(extract_json('说明```json\n{"a": 1}\n```')["a"], 1)
        self.assertEqual(extract_json('xx {"a": {"b": "}"}} yy')["a"]["b"], "}")

    def test_zodiac(self):
        self.assertEqual(zodiac_of(normalize_date("1924-05-01"))[0], "鼠")
        self.assertIsNone(zodiac_of(normalize_date("1924-02-10"))[0])  # 须核对农历
        self.assertIsNone(zodiac_of(normalize_date("1924"))[0])  # 仅知年份

    def test_locate_quote(self):
        text = "第一段。\n测试甲帝生于1500年10月3日，卒于1560年。\n第三段。"
        ok, off, para, ctx = locate_quote(text, "测试甲帝生于 1500年10月3日")
        self.assertTrue(ok)
        self.assertIn("第一段", ctx)
        self.assertFalse(locate_quote(text, "测试甲帝降生于1500年")[0])


class TestLedger(Tmp):
    def test_tamper_detected(self):
        p, _ = self.demo_project()
        p.log("程序", "测试", content={"x": 1})
        p.log("程序", "测试", content={"x": 2})
        self.assertTrue(p.verify_chain()[0])
        c = sqlite3.connect(p.db_path)
        c.execute("UPDATE events SET content='{\"x\":999}' WHERE seq=2")
        c.commit()
        ok, bad, _ = p.verify_chain()
        self.assertFalse(ok)
        self.assertEqual(bad, "E000002")


class FlakyProvider:
    def __init__(self, script):
        self.script = list(script)
        self.calls = []

    def complete(self, model, system, user, max_tokens, timeout):
        self.calls.append(user)
        x = self.script.pop(0)
        if isinstance(x, Exception):
            raise x
        return x, 10, 10


class TestRetry(Tmp):
    def hub(self, script):
        p, st = self.demo_project()
        prov = FlakyProvider(script)
        waits = []
        hub = ModelHub(p, st, {}, providers={"mock|": prov}, sleep=waits.append)
        return p, hub, prov, waits

    def test_transport_then_success(self):
        p, hub, prov, _ = self.hub([TransportError("x"), TransportError("y"), '{"ok": 1}'])
        self.assertEqual(hub.call_json("P1", "s", "u", call_key="k1", round_=1)["ok"], 1)
        self.assertEqual(len(prov.calls), 3)
        self.assertEqual(prov.calls[0], prov.calls[2])  # 传输类重试原样重发

    def test_format_retry_appends_note(self):
        p, hub, prov, _ = self.hub(["不是 JSON", '{"ok": 1}'])
        hub.call_json("P1", "s", "u", call_key="k2", round_=1)
        self.assertIn("格式错误说明", prov.calls[1])

    def test_fatal_pauses_immediately(self):
        p, hub, prov, _ = self.hub([FatalCallError("鉴权失败")])
        with self.assertRaises(CallFailedPause):
            hub.call_json("P1", "s", "u", call_key="k3", round_=1)
        self.assertEqual(len(prov.calls), 1)
        self.assertTrue(p.q("SELECT 1 FROM events WHERE type='调用失败暂停'"))

    def test_all_retries_fail_then_pause(self):
        p, hub, prov, _ = self.hub([TransportError("x")] * 7)
        with self.assertRaises(CallFailedPause):
            hub.call_json("P1", "s", "u", call_key="k4", round_=1)
        self.assertEqual(len(prov.calls), 7)  # 首次 + 两批各 3 次


class TestDemoFlow(Tmp):
    def run_demo(self):
        p, st = self.demo_project()
        hub = ModelHub(p, st, {}, providers=demo.providers(), sleep=lambda s: None)
        res = Flow(p, st, hub, Retriever(p, MockSearch(demo.PAGES))).run()
        return p, res, report.build(p)

    def test_outcomes(self):
        p, res, c = self.run_demo()
        self.assertEqual(res, "完成")
        byid = {r["条目"]: r for r in c["逐条结果"]}
        self.assertEqual(byid["I01"]["结论"], "查到")
        self.assertEqual(byid["I01"]["独立验证次数"], 1)
        self.assertEqual(byid["I02"]["独立验证次数"], 0)  # 同一来源不计独立
        self.assertEqual(byid["I03"]["结论"], "有争议")
        self.assertEqual(byid["I04"]["结论"], "资料缺载")
        self.assertTrue(c["账本完整性"]["完整"])

    def test_fabricated_quote_caught(self):
        p, _, _ = self.run_demo()
        b = p.q("SELECT * FROM blocks WHERE block_id='P2-R1-B002'")[0]
        self.assertEqual(b["st_check"], "未查证")
        self.assertIn("原句未在所注检索的存档原文中找到", b["flags"])

    def test_resume_uses_cached_calls(self):
        p, st = self.demo_project()
        router = demo.providers()["mock|"]
        orig = router.map["mock-c"]
        state = {"fail": True}

        def flaky(model, system, user):
            if state["fail"]:
                raise TransportError("审查者掉线")
            return orig(model, system, user)
        router.map["mock-c"] = flaky
        hub = ModelHub(p, st, {}, providers={"mock|": router}, sleep=lambda s: None)
        res = Flow(p, st, hub, Retriever(p, MockSearch(demo.PAGES))).run()
        self.assertTrue(res.startswith("调用失败暂停"))
        n_calls_before = p.q("SELECT COUNT(*) c FROM calls WHERE role='P1' AND status='成功'")[0]["c"]
        n_retr_before = p.q("SELECT COUNT(*) c FROM retrievals")[0]["c"]
        state["fail"] = False
        res2 = Flow(p, st, hub, Retriever(p, MockSearch(demo.PAGES))).run()
        self.assertEqual(res2, "完成")
        # 第 1 轮生产者的调用没有重复发出；检索也没有重复
        r1 = p.q("SELECT COUNT(*) c FROM calls WHERE role='P1' AND call_id LIKE 'R1-%' AND status='成功'")[0]["c"]
        self.assertEqual(r1, 2)
        self.assertEqual(p.q("SELECT COUNT(*) c FROM retrievals WHERE round=1")[0]["c"], n_retr_before)
        self.assertTrue(p.verify_chain()[0])


if __name__ == "__main__":
    unittest.main()


class TestHardening(Tmp):
    def test_bom_secrets(self):
        from mmv.config import load_secrets
        f = self.dir / "k.env"
        f.write_bytes("﻿ANTHROPIC_API_KEY=abc\n".encode("utf-8"))
        self.assertEqual(load_secrets(f).get("ANTHROPIC_API_KEY"), "abc")

    def test_search_auth_failure_pauses(self):
        import urllib.error
        p, st = self.demo_project()

        class Bad:
            def search(self, q, n):
                raise urllib.error.HTTPError("u", 401, "no", {}, None)
        with self.assertRaises(CallFailedPause):
            Retriever(p, Bad(), sleep=lambda s: None).search("P1", 1, "x", 3)

    def test_search_transient_then_pause(self):
        import urllib.error
        p, st = self.demo_project()

        class Down:
            def search(self, q, n):
                raise urllib.error.URLError("down")
        with self.assertRaises(CallFailedPause):
            Retriever(p, Down(), sleep=lambda s: None).search("P1", 1, "x", 3)

    def test_wrong_shape_json_is_format_retry(self):
        p, st = self.demo_project()
        prov = FlakyProvider(['{"searches": ["just a string"]}', '{"searches": []}'])
        hub = ModelHub(p, st, {}, providers={"mock|": prov}, sleep=lambda s: None)
        from mmv.util import FormatError

        def val(o):
            for q in o["searches"]:
                if not isinstance(q, dict):
                    raise FormatError("须是对象")
        hub.call_json("P1", "s", "u", call_key="k9", round_=1, validator=val)
        self.assertEqual(len(prov.calls), 2)

    def test_same_series_producers_not_independent(self):
        p, st = self.demo_project()
        st["roles"]["P2"]["series"] = "模拟A"
        hub = ModelHub(p, st, {}, providers=demo.providers(), sleep=lambda s: None)
        Flow(p, st, hub, Retriever(p, MockSearch(demo.PAGES))).run()
        c = report.build(p)
        i1 = next(r for r in c["逐条结果"] if r["条目"] == "I01")
        self.assertEqual(i1["独立验证次数"], 0)
        self.assertEqual(i1["独立性"], "未独立验证")

    def test_file_hash_verify(self):
        p, st = self.demo_project()
        hub = ModelHub(p, st, {}, providers=demo.providers(), sleep=lambda s: None)
        Flow(p, st, hub, Retriever(p, MockSearch(demo.PAGES))).run()
        self.assertEqual(p.verify_files(), [])
        f = next((p.root / "archive").iterdir())
        f.write_text("被改过", encoding="utf-8")
        self.assertTrue(p.verify_files())
